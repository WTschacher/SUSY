SUSY
----

SUSY computes synchrony as windowed cross-correlation based on two-dimensional time series, as described in Tschacher, Rees & Ramseyer (2014).

----

Installation:
```r
install.packages("SUSY", repos="https://WTschacher.github.io/SUSY")
```

[Documentation](https://WTschacher.github.io/SUSY)
